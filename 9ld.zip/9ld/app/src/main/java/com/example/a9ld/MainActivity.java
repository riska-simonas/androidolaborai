package com.example.a9ld;

import static java.lang.Double.parseDouble;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    EditText lat, lon;
    Button goBtn;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.maps);
        mapFragment.getMapAsync(this);

        lat = findViewById(R.id.lat);
        lon = findViewById(R.id.lon);
        goBtn = findViewById(R.id.button);



    }


    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        DB = new DBHelper(this);
        Cursor res = DB.getCoordinates();
        if (res.getCount() != 0) {
            while(res.moveToNext()){
                LatLng location = new LatLng(parseDouble(res.getString(0)), parseDouble(res.getString(1)));
                googleMap.addMarker(new MarkerOptions().position(location));
                googleMap.moveCamera(CameraUpdateFactory.newLatLng(location));
            }
        }
        goBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String latTXT = lat.getText().toString();
                String lonTXT = lon.getText().toString();
                Boolean checkInsertData = DB.insertCoordinates(latTXT, lonTXT);
                if (checkInsertData==true) {
                    Toast.makeText(MainActivity.this, "New coordinates inserted", Toast.LENGTH_SHORT).show();
                    LatLng location = new LatLng(parseDouble(latTXT), parseDouble(lonTXT));
                    googleMap.addMarker(new MarkerOptions().position(location));
                    googleMap.moveCamera(CameraUpdateFactory.newLatLng(location));
                } else {
                    Toast.makeText(MainActivity.this, "Insertion failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}